
  var count = 1; 

  function increment()
  {
      var a = document.querySelector("#counter1");

       count = count+ 1;

       a.innerHTML = count;
  }

    function decrement()
    {
        var a = document.querySelector("#counter1");

        count = count - 1;

        a.innerHTML = count;
    }

      function comment()
      {
          var read = document.querySelector("#inputid").value;

          const a = document.querySelector("#commentbox");

            var element = document.createElement("div");

             element.textContent=read;

          a.insertBefore(element,a.firstChild);

          document.querySelector("#inputid").value=" ";


      }