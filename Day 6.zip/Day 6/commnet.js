
   var counter  = 1;

function comment()
{

     

    const newElement = document.createElement("div");

    newElement.textContent = "user commnet" + counter;


     const idcomment  = document.querySelector("#idcomment");

     idcomment.appendChild(newElement);

            counter++;
   


}