
  var count = 0;

function increment()  // increment like counter
{

      var a = document.querySelector("#buttonid");

        count++;

      a.innerHTML="Like" + " " + count;

}

function comment()  // overides comment
{
     var read = document.querySelector("#inputid").value;  //read 

     var  a = document.querySelector("#commnetref"); // div box


        a.innerHTML=read;

    document.querySelector("#inputid").value=" ";
}

  function commentsequence()  // comment one after another
  {

       var read = document.querySelector("#inputid").value;

       var a = document.querySelector("#commnetref");

       var element = document.createElement("div");

        element.textContent=read;

        a.insertBefore(element,a.firstChild);

        document.querySelector("#inputid").value = " ";
       

  }

