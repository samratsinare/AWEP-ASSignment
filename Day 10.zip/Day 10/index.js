

  var counter = 1;

  function increment()
  {
         var a = document.querySelector("#counter1");

         counter = counter + 1 ;

         a.innerHTML=counter;
  }

    function decrement()
    {
        var b = document.querySelector("#counter1");

        counter = counter - 1 ;

        b.innerHTML = counter;
    }

     var count = 0; 

    function comment()
    {
    
        
        let userComment = document.querySelector("#commentid").value; 

       const newElement = document.querySelector("#commnethere")

       count++;

        newElement.innerHTML = count + " " + userComment;

        const commentBox = document.querySelector("#commentBox");

        commentBox.appendChild(newElement);

       commentBox.insertBefore(newElement, commentBox.firstChild);

       document.querySelector("#commentid").value = "";




    }