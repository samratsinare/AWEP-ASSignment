
  function msg()
  {
      alert("hello welcom");
  }